<?php $__env->startSection('content'); ?>
<div class="container">
<div class="form-group row mb-0">
    <div style="text-align:right; padding-bottom:20px;" class="col-md-6 offset-md-4">
    <a href="<?php echo e(url('/field/create')); ?>" class="btn btn-primary">Add Fields</a>                               
    </div>
</div>
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header"><?php echo e(__('Fields')); ?></div>

<div class="card-body">
<table class="table table-striped">
    <thead>
        <tr>            
            <th> Name</th>
            <th> Crops  </th>
            <th> Area </th>               
            <th> Actions </th>                      
        </tr>
    </thead>
    <tbody>       
    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          <tr>
              <td> <?php echo e($field->name); ?> </td>
              <td> <?php echo e($field->typeofcrops); ?> </td>
              <td> <?php echo e($field->area); ?> </td>
              <td><a class="btn btn-primary" href="/field/edit/<?php echo e($field->id); ?>">Edit</a> <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="/field/delete/<?php echo e($field->id); ?>">Delete</a></td>             
          </tr>         
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\agriculture\resources\views/fields/fields.blade.php ENDPATH**/ ?>