<?php $__env->startSection('content'); ?>
<div class="container">
<div class="form-group row mb-0">
    <div style="text-align:right; padding-bottom:20px;" class="col-md-6 offset-md-4">
    <a href="<?php echo e(url('/process/create')); ?>" class="btn btn-primary">Add Process</a>                               
    </div>
</div>
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header"><?php echo e(__('Process')); ?></div>

<div class="card-body">
<table class="table table-striped">
    <thead>
        <tr>            
            <th> Name</th>
            <th> Crops  </th>
            <th> Date  </th>
            <th> Area </th>               
            <th> Actions </th>                      
        </tr>
    </thead>
    <tbody>       
    <?php $__currentLoopData = $process; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          <tr>
              <td> <?php echo e($processs->selectatractor); ?> </td>
              <td> <?php echo e($processs->selectafield); ?> </td>
              <td> <?php echo e($processs->date); ?> </td>
              <td> <?php echo e($processs->area); ?> </td>
              <td><a class="btn btn-primary" href="/process/edit/<?php echo e($processs->id); ?>">Edit</a> <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="/process/delete/<?php echo e($processs->id); ?>">Delete</a></td>             
          </tr>         
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\agriculture\resources\views/process/process.blade.php ENDPATH**/ ?>