@extends('layouts.app')

@section('content')
<div class="container">
<div class="form-group row mb-0">
    <div style="text-align:right; padding-bottom:20px;" class="col-md-6 offset-md-4">
    <a href="{{ url('/tractor/create') }}" class="btn btn-primary">Add Tractor</a>                               
    </div>
</div>
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header">{{ __('Tractors') }}</div>

<div class="card-body">
<table class="table table-striped">
    <thead>
        <tr>            
            <th> Tractor Name</th>                                  
        </tr>
    </thead>
    <tbody>       
    @foreach($tractors as $tractor)  
          <tr>
              <td> {{$tractor->tractor_name}} </td>              
              <td><a class="btn btn-primary" href="/tractor/edit/{{$tractor->id}}">Edit</a> <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="/tractor/delete/{{$tractor->id}}">Delete</a></td>             
          </tr>         
    @endforeach
   </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
@endsection
