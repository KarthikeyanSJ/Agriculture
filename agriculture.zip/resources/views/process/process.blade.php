@extends('layouts.app')

@section('content')
<div class="container">
<div class="form-group row mb-0">
    <div style="text-align:right; padding-bottom:20px;" class="col-md-6 offset-md-4">
    <a href="{{ url('/process/create') }}" class="btn btn-primary">Add Process</a>                               
    </div>
</div>
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header">{{ __('Process') }}</div>

<div class="card-body">
<table class="table table-striped">
    <thead>
        <tr>            
            <th> Name</th>
            <th> Crops  </th>
            <th> Date  </th>
            <th> Area </th>               
            <th> Actions </th>                      
        </tr>
    </thead>
    <tbody>       
    @foreach($process as $processs)  
          <tr>
              <td> {{$processs->selectatractor}} </td>
              <td> {{$processs->selectafield}} </td>
              <td> {{$processs->date}} </td>
              <td> {{$processs->area}} </td>
              <td><a class="btn btn-primary" href="/process/edit/{{$processs->id}}">Edit</a> <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="/process/delete/{{$processs->id}}">Delete</a></td>             
          </tr>         
    @endforeach
   </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
@endsection
