@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Process') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ url('/process/store') }}">
                        @csrf

                        <div class="form-group row">
                        <label for="crops" class="col-md-4 col-form-label text-md-right">{{ __('Select a Tractor') }}</label>
                            <div class="col-md-6">
                                <select required class="form-control @error('crops') is-invalid @enderror" name="selectatractor">                                   
                                    @foreach($tractor as $tract)
                                    <option value="{{$tract->tractor_name}}">{{$tract->tractor_name}}</option>
                                    @endforeach                                
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="crops" class="col-md-4 col-form-label text-md-right">{{ __('Select a Field') }}</label>
                            <div class="col-md-6">
                                <select required class="form-control @error('crops') is-invalid @enderror" name="selectafield">
                                    @foreach($fields as $field)
                                    <option value="{{$field->name}}">{{$field->name}}</option>
                                    @endforeach                                  
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="area" class="col-md-4 col-form-label text-md-right">{{ __('Process Date') }}</label>

                            <div class="col-md-6">
                                <input id="date" type="date" class="form-control @error('area') is-invalid @enderror" name="date" required>

                                @error('date')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="area" class="col-md-4 col-form-label text-md-right">{{ __('Process Area') }}</label>

                            <div class="col-md-6">
                                <input id="area" type="text" class="form-control @error('area') is-invalid @enderror" name="area" required>Sq.ft

                                @error('area')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                       

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Submit') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


<script>
</script>