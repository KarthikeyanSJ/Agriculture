@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Process') }}</div>

                <div class="card-body">
                    <form method="POST" action="/process/update/{{ $process->id }}">
                        @csrf

                        <div class="form-group row">
                            <label for="crops" class="col-md-4 col-form-label text-md-right">{{ __('Select a Tractor') }}</label>
                            <div class="col-md-6">
                                <select required class="form-control @error('crops') is-invalid @enderror" name="crops">
                                    <option value="Wheat" {{$fields->selectatractor == 'Wheat'?'selected':''}}>Wheat</option>
                                    <option value="Broccoli" {{$fields->selectatractor == 'Broccoli'?'selected':''}}>Broccoli</option>
                                    <option value="Strawberries" {{$fields->selectatractor == 'Strawberries'?'selected':''}}>Strawberries</option>                                    
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="crops" class="col-md-4 col-form-label text-md-right">{{ __('Select a Field') }}</label>
                            <div class="col-md-6">
                                <select required class="form-control @error('crops') is-invalid @enderror" name="crops">
                                    <option value="Wheat" {{$fields->selectafield == 'Wheat'?'selected':''}}>Wheat</option>
                                    <option value="Broccoli" {{$fields->selectafield == 'Broccoli'?'selected':''}}>Broccoli</option>
                                    <option value="Strawberries" {{$fields->selectafield == 'Strawberries'?'selected':''}}>Strawberries</option>                                    
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="area" class="col-md-4 col-form-label text-md-right">{{ __('Process Date') }}</label>

                            <div class="col-md-6">
                                <input id="area" type="text" class="form-control @error('area') is-invalid @enderror" name="area" value="{{ $fields->area }}" required>     Sq.ft                           
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="area" class="col-md-4 col-form-label text-md-right">{{ __('Process Area') }}</label>

                            <div class="col-md-6">
                                <input id="area" type="text" class="form-control @error('area') is-invalid @enderror" name="area" value="{{ $fields->area }}" required>     Sq.ft                           
                            </div>
                        </div>
                       

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Update') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
