@extends('layouts.app')

@section('content')
<table>
    <thead>
        <tr>            
            <th> Name</th>
            <th> Crops  </th>
            <th> Area </th>            
        </tr>
    </thead>
    <tbody>         
          <tr>
              <td> Test </td>
              <td> Test </td>
              <td> Test </td>
          </tr>         
   </tbody>
</table>@endsection
