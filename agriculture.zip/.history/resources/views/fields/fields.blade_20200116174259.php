@extends('layouts.app')

@section('content')
<div class="container">
<div class="form-group row mb-0">
    <div style="text-align:right; padding-bottom:20px;" class="col-md-6 offset-md-4">
    <a href="{{ url('/field/create') }}" class="btn btn-primary">Add Fields</a>                               
    </div>
</div>
<div class="row justify-content-center">
<div class="col-md-8">
<div class="card">
<div class="card-header">{{ __('Fields') }}</div>

<div class="card-body">
<table>
    <thead>
        <tr>            
            <th> Name</th>
            <th> Crops  </th>
            <th> Area </th>               
            <th> Actions </th>                      
        </tr>
    </thead>
    <tbody>       
    @foreach($fields as $field)  
          <tr>
              <td> {{$field->name}} </td>
              <td> {{$field->typeofcrops}} </td>
              <td> {{$field->area}} </td>
              <td><a class="btn btn-primary" href="/field/edit/{{$field->id}}">Edit</a></td>
              <td><a class="btn btn-danger" href="">Delete</a></td>              
          </tr>         
    @endforeach
   </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
@endsection
