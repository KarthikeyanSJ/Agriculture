@extends('layouts.app')

@section('content')
<table>
    <thead>
        <tr>            
            <th> Name</th>
            <th> Crops  </th>
            <th> Area </th>            
        </tr>
    </thead>
    <tbody>
         @foreach($users as $user)
          <tr>
              <td> {{$user->id}} </td>
              <td> {{$user->name}} </td>
              <td> {{$user->last_name}} </td>
              <td> {{$user->email}} </td>
              <td> {{$user->phone}} </td>
              <td> {{$user->address}} </td>
          </tr>
         @endforeach
   </tbody>
</table>@endsection
