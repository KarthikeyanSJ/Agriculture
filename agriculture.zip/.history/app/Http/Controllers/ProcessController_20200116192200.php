<?php

namespace App\Http\Controllers;

use App\Process;
use App\Tractor;
use App\Field;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProcessController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $process = DB::table('process')->get();
        return view('process/process',['process' => $process]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tractor = Tractor::get(); 
        $fields = Field::get();        
        return view('process/create',['tractor' => $tractor,'fields' => $fields]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user= new Process();
        $user->selectatractor= $request['selectatractor'];         
        $user->selectafield= $request['selectafield'];         
        $user->date= $request['date'];         
        $user->area= $request['area'];         
        $user->save();            
        return redirect('/process');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Process  $process
     * @return \Illuminate\Http\Response
     */
    public function show(Process $process,Request $request)
    {
        $id =  $request->id;
        $process = Process::find($id);        
        return view('process/edit',['process' => $process]); 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Process  $process
     * @return \Illuminate\Http\Response
     */
    public function edit(Process $process)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Process  $process
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Process $process)
    {
        $id =  $request->id;
        $user = Process::find($id);          
        $user->selectatractor= $request['selectatractor'];         
        $user->selectafield= $request['selectafield'];         
        $user->date= $request['date'];         
        $user->area= $request['area']; 
        $user->save();            
        return redirect('/process');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Process  $process
     * @return \Illuminate\Http\Response
     */
    public function destroy(Process $process,Request $request)
    {
        $id =  $request->id;
        $user = Process::find($id);
        $user->delete();
        return redirect('/process');
    }
}
